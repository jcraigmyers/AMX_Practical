The files contained in this zip are those required to complete the
Programming Certification. 

The System Requirements will set the guidelines and
expectations for this certification. This document contains
the instructions and requirements for your Practical Exam. 

The Device Specifications will assist you with protocol
and device behavior. 

The Touch Panel file is available to assist
with your programming. 

The Video Flow Diagram will serve as a visual aide in understanding
the video flow for your desired program. 

The connectorDetail diagrams the connectors.

The controlSingleLines diagrams control. 

The NetLinxPracticalExamEmulator will allow you to test your program.

The EMU_README.TXT will explain how to use the Emulator.   

